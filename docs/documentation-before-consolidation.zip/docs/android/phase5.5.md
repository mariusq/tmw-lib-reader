# Android Phase 5.5 — lookup history and sync

Implemented on 2026-10-04. Phase 6 remains responsible for the full UI redesign,
Japanese reader presentation and Android lifecycle work. Existing uncommitted
Phase 4/5 work was preserved. Physical-phone Phase 5 sync acceptance remains
pending, as does physical-phone Phase 5.5 acceptance.

## Behavior and protocol

A successful, still-current word tap displays definitions immediately, then
submits a bounded native history save asynchronously. It requires no passage,
bookmark or note. Failed or superseded lookups are not recorded. SQLite commits
the event and its outgoing operation/device counter atomically. Normal repeated
taps are distinct events; network retries reuse durable IDs. Opening definitions
from history does not itself add another reader-tap event.

History is available in the library and reader through a minimal expandable
view. Native search covers normalized word, headword, reading, sentence and
dictionary label; pages contain 50 rows, with one additional row queried to
detect the next page. Search is debounced by 250 ms and stale responses are
ignored. Definitions resolve offline from the installed dictionary. Reader
navigation is shown only for the same catalog/book/verified content version,
or the exact identified local proof copy. Legacy unknown-version records retain
context without a jump. Opening a different downloaded book from global history
is deferred; open its reader first to navigate.

The [history protocol extension](phase5-protocol.md#phase-55-history-extension)
defines portable dictionary references, ordering, intentional repeats,
retention, capability backfill and terminal deletion. Phone recording preferences
are local and independent of desktop recording preferences. Incoming history
continues when recording is disabled. Retention defaults to 10,000 active events;
lowering it deletes older known events and syncs tombstones. Clear/delete also
sync known-event tombstones. Unknown offline and future lookups can arrive after
clear. A retained phone tombstone survives desktop restore and is requeued.

History uses Phase 5's ordered native queue, receipts, transactional pages,
high-water overlays, automatic retry/backoff and visible sync status. Old v3
clients continue progress/passage sync without receiving unknown history kinds.
The first 5.5 phone startup resets existing pull cursors once to backfill skipped
desktop history, preserving pending state. Update both applications: older
desktop builds cannot accept history operations, which remain queued on failure.
OS background scheduling while suspended/killed is still deferred; reopening
the app resumes the durable queue.

## Data preservation and limitations

Desktop schema 18 is additive. Existing history rows receive stable identities
and journal backfill without replacing original word/context/count identity or
preferences. Existing migration/backup/restore tests pass. No destructive
migration or source cleanup was performed. For a future destructive change,
use the desktop Backup action to an external-to-library destination such as
`%USERPROFILE%\Documents\TMW backups\catalog-before-history-change.sqlite3`.
Mobile private data remains below `/data/user/0/com.tmw.companion/`; user-facing
export remains Phase 7. In-place update preserves the application identifier and
signing identity; never uninstall or clear application data to update.

History survives download removal, cover-cache clearing, source unavailability,
replacement and catalog-book deletion. Manually imported proof-book history is
local-only; no catalog association is guessed. The implementation reads neither
`F:\tmw collection` nor `testLibrary/` during this task. No source EPUB or source
directory was written, renamed, moved, uploaded or deleted. Tests use isolated
SQLite/synthetic fixtures. Private transport and native credentials retain the
existing Phase 5 boundaries.

Retention bounds visible events, not total database storage. Terminal markers,
the immutable journal, receipts and rejected/recovery payloads are not compacted.
Clear is not secure erasure. A very long-lived catalog can grow; compaction
requires a separate protocol/storage design. During bounded backfill, temporary
materialized active history may exceed the configured phone limit until the pull
finishes; premature pruning must not discard pending newer events.

## Validation and update artifact

- Desktop Rust regression: 47 passed, 7 ignored; initial final run took 3.45 s
  (10.8 s including compilation). Windows release build passed in 35.71 s.
  A later malformed-version validation repair has separate affected results below.
- Android frontend: 11 tests passed in the full Android group (1.40 s), followed
  by the affected history group, 3 passed (1.03 s), adding one distinct UI test
  for a total of 12. Coverage includes an ordinary completed word tap without
  a saved passage, bounded dictionary references, exact-copy navigation,
  paginated requests and stale history searches, alongside Phase 5 behavior.
  TypeScript and ESLint passed. The production build passed with the existing
  Vite chunk-size warning.
- Native Android: eight tests passed on the existing Android 16/API 36 x86-64
  emulator in 0.962 s. Coverage includes repeated offline events, lost responses,
  idempotent delivery, disabled recording, retention, terminal deletes,
  proof-only history, passage isolation, capability backfill and restore-epoch
  deletion recovery, plus the five existing Phase 5 storage regressions. The
  final affected history test passed in 0.210 s after test-only Unicode/timing
  instrumentation changes. Existing emulator data and signing key were retained.
- Two isolated native offline history commits took 54.3 ms total (~27.2 ms each)
  in the small instrumentation fixture, including first-use/JIT overhead. This
  measures storage, not end-to-end tap latency. Phase 2 warm lookup evidence was
  0.8–1.6 ms (vertical inflection 0.9 ms; split element 1–17 ms). The lookup Rust
  implementation is unchanged and the frontend test verifies that result
  handling submits persistence separately. Real-phone latency with concurrent
  sync remains unmeasured; no claim of measured latency equivalence is made.

The affected Rust sync group passed four tests after malformed history content
versions were made durable per-record rejections; its test execution took 0.21 s.
The updated Windows release build passed in 51.03 s. The broad suite was not
repeated because only this validated history path changed.

Signed ARM64 artifact:
`apps/android/src-tauri/gen/android/app/build/outputs/apk/arm64/release/app-arm64-release.apk`.
Package `com.tmw.companion`, version **0.5.5**, versionCode **5005**, minimum API
24; **88,841,067 bytes**. SHA-256:
`710a23a1737b107e6d5f9b76a0e4f9a98bf47f25eb2a79daaea8a4b2317c7807`.
The ARM64 Rust release compilation took 45.91 s and Gradle packaging took 53 s,
after existing dictionary provisioning and the frontend build. APK v2 signature
verification and 16 KB ZIP alignment passed. Certificate SHA-256
`606342f7138cbc6eaee5b672b9d9961cc9ca70d2e3f4eacb53cbd4a47f543ca8`
matches the existing emulator update wrapper/development signing identity.
The existing key was reused, not recreated. Artifacts and keys remain ignored.

The existing emulator wrapper was updated by native regression work without
uninstalling or clearing data. A final brief activity launch passed (`am start
-W`, cold activity **826 ms**). This wrapper reuses prior x86-64 Rust/frontend
assets and exercises current native storage; its smoke does not verify the new
ARM64 frontend end to end. The ARM64 package contains the new frontend and Rust
assets; it was not installed because no physical phone was attached. No second
ABI Rust build, Windows installer or live-user-catalog restart was performed.
The standalone desktop executable is
`src-tauri/target/release/tmw-epub-library.exe`.

Commands from the repository root:

```powershell
cargo test --offline --manifest-path src-tauri/Cargo.toml --lib
cargo test --offline --manifest-path src-tauri/Cargo.toml --lib user_sync
cargo build --offline --manifest-path src-tauri/Cargo.toml --release --features tauri/custom-protocol
& 'C:\Program Files\nodejs\npm.cmd' exec vitest -- run apps/android/src
& 'C:\Program Files\nodejs\npm.cmd' exec tsc -- --noEmit -p apps/android/tsconfig.json
& 'C:\Program Files\nodejs\npm.cmd' exec eslint -- apps/android/src
& .\apps\android\Android.ps1 -Action Build -TestSigning -Target aarch64
# Existing SDK/Java/Gradle environment; no initialization or data wipe.
$native='apps/android/src-tauri/gen/android'
& "$native/gradlew.bat" -p $native assembleX86_64Debug assembleX86_64DebugAndroidTest -x rustBuildX86_64Debug --offline --no-daemon --no-configuration-cache
adb -s emulator-5554 install -r <existing-debug-wrapper.apk>
adb -s emulator-5554 install -r <debug-test.apk>
adb -s emulator-5554 shell am instrument -w -e class com.tmw.companion.UserSyncStorageTest com.tmw.companion.test/androidx.test.runner.AndroidJUnitRunner
apksigner verify --verbose --print-certs <arm64-release.apk>
zipalign -c -P 16 4 <arm64-release.apk>
git diff --check
```

Approximate wall-time accounting: **18 minutes implementation/review/documentation
and 5 minutes validation, builds, packaging and smoke (~22% validation)**.
Overlapping checks are counted once; implementation was not padded. Concrete
failure/repair checks are included. Prior Phase 1–5 evidence was reused. Restricted
esbuild/Gradle/ADB access used approved shells; no toolchain was reinstalled.
The initial signature command lacked Java environment configuration; the
affected command passed with the existing Java path. Final diff/readback passed.

## Pending physical acceptance

Install the signed ARM64 APK in place and run the updated standalone Windows
executable. Enable the existing private service and re-pair if the grant remains
revoked. Complete ordinary offline word taps, restart, reconnect and verify phone
and desktop history convergence. Check simultaneous desktop/phone taps, loss of
the private connection after server commit, disabled recording with incoming
sync, dictionary revision differences, retention and clear with another offline
device. Verify exact-version jumps and retained context after source replacement,
book/download removal and cover clearing. Physical Phase 5 progress/note sync
remains independently pending. No Phase 6 work was performed.

## User-confirmed physical-phone acceptance — 2026-10-04

Before Phase 6, the user confirmed that everything passed on the physical phone
after Phase 5.5, including the prior Phase 5 behavior. This is user-reported
acceptance, separate from the automated/emulator evidence above. Earlier pending
physical acceptance lists are superseded by this report; no phone timings or
device details were supplied. Phase 6 changes require fresh physical acceptance.
