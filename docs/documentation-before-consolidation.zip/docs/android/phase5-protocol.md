# Phase 5 user-data protocol

The authenticated private desktop API adds `POST /v3/user-sync`. Existing v1/v2 routes remain compatible. The service remains opt-in and loopback-only. No client paths are accepted, and source EPUBs are opened read-only.

Request:

```json
{"catalogId":"catalog namespace","epoch":"last returned epoch, optional initially","cursor":0,"operations":[{"id":"unique durable operation ID","sequence":1,"bookId":"32-character public book ID","kind":"progress","contentVersion":"sha256-…","fields":{"locationCfi":"epubcfi(…)"}}]}
```

Passage operations use `kind: "passage"` and a stable 32-character hex `entityId`. Creation supplies surface, optional headword/reading, sentence, note, and locationCfi. Subsequent patches may change sentence and note independently. Missing fields retain existing values; null clears a field. Anchored identity fields are immutable after creation. Deletion supplies `deleted: true` and creates a permanent entity tombstone, including when no passage has arrived yet. Saving a new passage after deletion requires a new entity ID.

Responses contain protocolVersion 3, catalogId, durable epoch, cursor, highWater, hasMore, acknowledged operation IDs, rejected `{id, reason}` records, and changes. Each change contains sequence, bookId, kind, entityId, deleted, contentVersion, and a full fields record. Empty operations pull changes. highWater is the maximum journal sequence after accepted operations in that transaction. Clients retain acknowledged local operation overlays until their durable pull cursor reaches that highWater, so earlier journal pages cannot temporarily erase an accepted local edit. Pages contain at most 50 records and 950,000 bytes of change data; requests are bounded to 16 operations and 65,536 body bytes. No wall-clock timestamps order competing edits.

SQLite serializes batches by server arrival/commit order. Progress is simple last-write-wins, including backwards moves. Device sequence counters must increase; gaps are permitted. Durable receipts keyed by authenticated device and operation ID make retries idempotent. A batch commits user records, journal entries, device sequence and receipts together. Invalid ordering rolls the entire batch back. Per-record rejections are durably receipted and returned again on retry; clients retain rejected local data for visible conflict handling. A reused passage ID cannot target another book.

Desktop SQL triggers journal local progress saves, passage creation, edits, and deletion in the same SQLite transaction. The immutable sequence journal permits consistent forward pagination while new writes arrive. It currently retains history without compaction. Restoring a desktop backup rotates the durable companion epoch; a stale epoch or cursor beyond the journal returns HTTP 409 `cursor_reset`. Clients reset their pull cursor/epoch while retaining pending offline operations. A different catalog namespace returns HTTP 409 `catalog_changed`.

The desktop verifies strong SHA-256 source versions on private API worker threads outside user-write transactions. Progress and new anchors require a matching current catalog source version; replacement, unavailable sources, or an unknown version reject the anchor operation with `content_version_changed`. Existing passage note/sentence edits and deletions remain possible without the source. Source stamps and remembered strong versions guard desktop reopening of synced anchors. Legacy desktop anchors without a strong version retain existing desktop behavior and sync with null contentVersion; mobile must preserve their data without silently applying an unknown-version CFI.

Migration 17 is additive: version fields, passage sync IDs, content-version records, journal, device sequences, receipts, and tombstones. It preserves existing progress, passages, metadata and source files. The desktop's existing catalog Backup action exports a standalone SQLite backup before any future destructive storage operation; keep that backup outside source roots, for example `%USERPROFILE%\\Documents\\TMW backups\\catalog-before-sync.sqlite3`. Restore uses existing migrations and invalidates old pull epochs. No live SQLite file is exchanged with Android. Clearing covers or removing phone copies does not remove user state.

On an epoch reset, mobile canonical records are regenerated. Pending unsent operations stay queued. Provisional acknowledgments from the old epoch are archived with `catalog_restored` for visible recovery, then removed as active overlays before restored PC history is replayed. This prevents an old watermark from overriding restored state indefinitely.

Metadata, tag and collection editing are deferred; they are not accepted over this endpoint.

## Phase 5.5 history extension

History-capable clients add `historyVersion: 1` to v3 requests. History uses
`kind: "history"`, a stable random 32-character hex `entityId`, and a separate
durable operation ID/device sequence for delivery. Events are immutable; a new
intentional tap always creates a new entity. Receipted retries create no extra
events. A different operation attempting to recreate an existing entity is
rejected with `immutable_history`; deleted entities reject creation with
`history_deleted`. Deletion is `deleted: true` with empty fields and works even
before creation. New intentional lookups after deletion use new identities.

Event fields are `surface`, nullable `headword`/`reading`, `sentence`,
`locationCfi`, `dictionaryId`, nullable `dictionaryEntryId`, optional
`dictionaryLabel`, and `lookedUpAt` (nonnegative epoch seconds encoded as a
string). Native saves bound word/reading to 256 UTF-16 units, sentence to 4,000,
CFI to 4,096, dictionary references to 128, label to 256 and timestamp to 32.
Server validation also bounds Unicode word/context lengths and UTF-8 request
size. No definitions, chapters, credentials or filesystem paths are transferred.
An empty `bookId` represents an unassociated catalog history event;
`contentVersion` is nullable or a verified SHA-256 version reference. History
is archival text and does not require current source availability/version.
Missing/deleted books retain the public book reference and text. Navigation
requires a matching known content version on the phone; desktop retains its
existing source checks and rejects mismatched version references.

Phone dictionary identity is
`jmdict-eng:20260928:5f54504a62a7f45741e1bf6fd28f6e1e5add6405f2829748cc004a802839a3aa`.
The current import does not preserve upstream entry sequence IDs, so
`dictionaryEntryId` is null; headword and reading provide a lexical reference.
Numeric SQLite entry IDs are never portable references. Existing desktop
dictionary provenance is marked `legacy-desktop`, with its dictionary label
when available. Opening a definition uses the installed dictionary and may
produce different results after a dictionary update; the original reference
remains unchanged. Counts preserve desktop normalized headword/reading identity,
with unresolved surface queries in a separate namespace.

Server journal/commit order governs shared order and retention. Device time is
informational only. Phone pending events appear first in local insertion order;
canonical events follow received server order. Retention does not prune newer
pending events behind older pull pages and applies after complete pull/overlay
catch-up. Desktop retains the latest 10,000 active events. Phone defaults to
10,000 per catalog (and independently for local proof history), configurable
from 1 to 10,000; the UI offers 100/1,000/10,000. Pruning creates terminal
tombstones and therefore removes those known events across synced devices.
Changing recording preferences is device-local. Disabled recording prevents
new local events but keeps existing records, incoming sync and queued delivery.

Clear deletes the current catalog's known history and local proof history;
it does not erect a clock-based global barrier. Unknown offline events and
future events can arrive afterward. Clear/delete/pruning tombstones remain
terminal through retries. Mobile keeps deleted markers across desktop restore
epoch resets and requeues their deletions against restored state. Clearing is
visible-history removal, not forensic erasure: journals, receipts and recovery
records retain historical payloads and have no compaction yet. Active retention
is not a bound on total sync-database storage.

Older v3 clients omit the capability: the desktop filters history changes while
advancing their cursor, preserving progress/passage sync. Upgrading the phone
replays existing cursors from zero once, without discarding existing user state,
queues, epochs or provisional overlays, to backfill previously skipped history.
Update the desktop with the phone; a pre-5.5 desktop cannot accept history
operations. Those operations remain durable rather than being discarded.
Migration 18 adds columns, stable IDs, history triggers/tombstones and legacy
backfill; it preserves existing visible history and preferences. Manual proof
EPUB history stays in the private `local-proof` namespace and never enters sync.

