# Android Phase 6 — lifecycle, reader polish and UI redesign

Implemented on 2026-10-04. This checkpoint stops at Phase 6. Phase 7 export,
backup UI and release distribution work were not implemented. All pre-existing
uncommitted Phase 4/5/5.5 work was preserved; no commits or resets were made.

## Prior acceptance reused

The user confirmed that **everything passed on the physical phone after Phase
5.5**, including the preceding progress/bookmark/note and history behavior.
This is user-reported physical acceptance, distinct from automated/emulator
results in phase5.md and phase5.5.md. The old pending phone lists in those reports
are superseded by this confirmation. No device model, phone timings, battery or
memory measurements were supplied. That confirmation does not accept the new
Phase 6 changes. It was also recorded in both Android instruction files.

## Audit and changes

The old reader saved on relocation, used a short embedded reading viewport, had
no font controls or explicit suspension checkpoint, and restarted on the catalog.
SQLite setup/recovery could run on the plugin command/UI thread on first use.
Native orientation configuration already retained the Activity, but the reader
had no explicit CFI-preserving reflow. Native Back already used WebView history.

* The app uses the desktop stone palette (#0c0a09, #1c1917) with amber #fbbf24.
  Library, Reader, History and Settings have a coherent bottom navigation outside
  reading. The catalog has rounded cover/book cards, amber offline Read actions,
  a collapsible filter/sort panel, distinct availability, and bounded pagination.
  Existing notes, history preferences, connection, cover-budget and notices
  controls remain available. Inputs/actions have at least 48 CSS-pixel targets.
* Following the user's refinement, reading fills the available viewport. Header
  and app navigation are hidden. Swipe upward from the bottom-center handle
  (at least 40 pixels, limited horizontal drift), or tap its 48-pixel target, to
  open the control sheet. It contains Exit reader, page buttons, 16–32 px font
  controls, book selection, bookmarks/passages and lookup history. The sheet is
  a native HTML dialog with focus containment. Android Back dismisses the sheet
  or definition before returning to Library; Exit checkpoints and returns there.
  System bars/cutouts remain respected rather than being covered with EPUB text.
* The reader uses warm paper (#faf7ef), Japanese serif fallbacks, 1.9 line height,
  and 0.55em ruby. Publication progression and fixed layout are preserved. Common
  body-only vertical declarations, including linked stylesheets, are promoted
  onto html before chapter serialization so epub.js chooses the proper axis.
  No Japanese-language guess or spine reordering was introduced.
* Font settings survive restart. Font changes and debounced ResizeObserver/
  rotation/resume reflow redisplay the current CFI. Transient reflow relocations
  do not become progress writes. Consecutive identical checkpoints are deduped;
  moving backwards still records progress normally. No furthest-position rule,
  rereading protection or sync-ordering change was added.
* Relocation remains the primary immediate save. Native onPause, visibilitychange,
  pagehide, component departure and opening/exiting controls additionally attempt
  a checkpoint. Native onResume triggers a resize. Abrupt OS termination cannot
  guarantee that a new asynchronous IPC has committed: already acknowledged
  SQLite operations and the content-keyed WebView CFI remain the recovery points.
* The last downloaded-book descriptor stores only app-owned filename, name,
  content identity and catalog identity. Process restart while reading reopens
  its private copy via the existing guarded native read command, then applies
  exact-version progress. Manual proof copies still recover from IndexedDB.
  Missing removed copies show an error and leave Library usable. No EPUB bytes
  are copied into localStorage. Durable pending sync remains native/local first.
* MainActivity supplies actual system-bar, cutout and keyboard insets as CSS
  variables, with WebView env() fallbacks. Initialization and storage recovery
  now run on a separate native storage dispatch worker, independent of pairing
  network requests; existing local/network/cover executor boundaries remain.
* EPUB archive parsing and entry decompression run in a dedicated Vite module
  worker. The per-book adapter uses the audited epub.js 0.3 archive interface;
  it does not modify global prototypes. Worker requests serialize inflation and
  enforce 10,000 entries, 16 MB per entry and 128 MB expanded bounds. Resources
  retain epub.js MIME/blob handling and sandboxing. Closing terminates the worker,
  rejects pending work and revokes blob URLs. JSZip is explicitly declared as an
  Android dependency. DOM/XML construction and pagination/layout necessarily
  remain in the WebView; this is not a claim that all epub.js work is off-thread.
  Tests without Worker retain the old constructor path. WebView worker startup
  failure does not silently retry decompression on the UI thread.
* Tap generation/order, glyph hit testing, scroll/movement/long-press exclusion,
  Unicode code-point offsets, ruby annotation exclusion and dictionary lookup
  implementation are preserved. Definitions paint before asynchronous history
  persistence. Dictionary size/timing debug text was removed from normal lookup.
* Vite now ignores native outputs/captures: packaging previously caused EBUSY
  watching a native library and stopped the local preview. Preview tooling does
  not change packaged runtime behavior.

## Validation and rendered evidence

The relevant Android frontend regression passed **16 tests in 7 files** (1.01 s
Vitest duration). It covers existing catalog/history/passages, exact-version
restore, native durable relocation, consecutive pause/pagehide dedup, backwards
progress, vertical/ruby treatment and font bounds. After the user requested
fullscreen reading, the changed Reader group passed **4 tests**, including a
bottom-edge swipe opening its dialog and Exit callback; 12.61 s total including
startup. There are **17 distinct passing tests** across these runs. The full
suite was not repeated after the narrowly scoped menu change.

TypeScript and production Vite build run as part of ARM64 packaging. ESLint has
zero errors and one existing-pattern exhaustive-deps warning about incrementing
lookup generation during effect cleanup. The first restricted esbuild run could
not read parent directories and was rerun in an approved shell. A later build
caught the new test's missing matcher TypeScript augmentation; its assertion was
changed to standard getAttribute equality. These failed attempts are included
in the validation budget, not reported as passes. The Vite large-chunk and
existing Gradle/Java deprecation warnings remain.

Actual current React/epub.js UI was inspected in the local browser with the
existing original generated vertical EPUB, not source-library material. It
opened through the worker and displayed Japanese, ruby and split text. The
final reader host filled a **390 × 844 CSS-pixel** viewport (measured DOM bounds:
390.4 × 844), without app chrome. Opening the controls and Exit to Library were
visually/semantically verified. Captures are ignored under
apps/android/.test-results/: phase6-reader-immersive.png and phase6-menu.png.
Earlier phase6-reader.png and phase6-reader-fullscreen.png captures are intermediate
layouts, not final fullscreen evidence. The browser has no native dictionary or
catalog bridge: browser rendering is not Android IPC/dictionary/sync acceptance.
The file chooser unexpectedly waited about 15 minutes; this is counted as
validation-only waiting. A fresh tab recovered the preview after its watcher
failure; no security restriction was bypassed.

No physical phone was attached; adb listed the existing emulator-5554 only.
No emulator reset, reinstall/uninstall, data clear, Android initialization or
signing-key change occurred. A second ABI build and broad emulator regression
were deliberately avoided. Prior native queue, credentials, history tombstone,
content-version, dictionary and protocol evidence from Phases 2–5.5 is reused:
those contracts/storage implementations are not changed in Phase 6. Native
lifecycle code is compiled by the ARM64 package; final native runtime behavior
requires the user's phone acceptance below.

## Signed update

Package com.tmw.companion, version **0.6.0**, versionCode **6000** (increased from
5005), ARM64 only, minimum API 24. Built with the existing SDK/JDK and development
signing key via Android.ps1 -Action Build -TestSigning -Target aarch64. The
initial successful package was superseded after the fullscreen refinement.
Final artifact/signature/hash and build timings are recorded below after final
verification. APKs, keys, dictionary assets, databases and screenshots stay ignored.

## Measurements, limits and remaining physical acceptance

The worker adds about 98 KB of production JavaScript. It retains one copied
compressed input for archive use alongside the selected copy; inflation is
serialized rather than retaining every decompressed entry. Large-publication
peak memory has not been measured; the existing 64 MB compressed-reader cap
remains. No new dictionary/catalog/cover-cache copies or storage migrations are
introduced. Phone battery/PSS/RSS/storage changes remain unmeasured; the Phase 2
observations are historical, not Phase 6 measurements. No wake locks or Android
background scheduling service was added. Queued work resumes on reopening using
the existing native scheduler; it is not guaranteed to sync while killed.

CSS cascade detection covers ordinary body selectors/inline declarations and
linked CSS, not arbitrary conditional rules, nested imports or unusual specificity.
Fixed-layout publications retain their own typography. Android Japanese serif
availability varies by device; no new font is bundled. TalkBack, keyboard IME
insets, vendor WebViews and real-book pagination still need device checks.

On the physical phone, update in place with the signed ARM64 APK and confirm:
fullscreen safe areas; bottom-edge swipe/tap, Close, Back and Exit; font size and
portrait/landscape position; Home/screen lock/resume; process termination and
airplane-mode reopening of the active download; quick ruby-base/inflected/split
word lookup without scroll-triggered lookup; bookmarks/notes/history and pending
sync after reconnect. Reuse already confirmed Phase 5.5 acceptance rather than
repeating its broad scenario matrix. Report any phone battery, memory or storage
observations separately from automated evidence.

F:\tmw collection and testLibrary/ were not accessed or altered. Only the existing
original generated reader fixture was read for rendering. No source EPUB or
source-library directory was written, uploaded, renamed, moved or deleted. No
private service configuration, credentials or PC source files were changed.

## Final artifact verification and time accounting

Final signed APK:
`apps/android/src-tauri/gen/android/app/build/outputs/apk/arm64/release/app-arm64-release.apk`

* Size: **88,877,107 bytes** (Phase 5.5: 88,841,067; increase 36,040 bytes).
* SHA-256: `2943eb9a5e55c01f1687fa1dee6aa891cff916ba9814eaa604b9ce759ac55af9`.
* `apksigner verify --verbose --print-certs`: passed, APK v2 signature.
* Certificate SHA-256:
  `606342f7138cbc6eaee5b672b9d9961cc9ca70d2e3f4eacb53cbd4a47f543ca8`,
  matching the prior update signing identity. No key was generated or changed.
* `zipalign -c -P 16 4`: passed. This checks ZIP alignment, not a 16 KB-device
  runtime claim (that remains unverified from earlier phases).
* `aapt dump badging`: com.tmw.companion, 0.6.0, versionCode 6000,
  min API 24 / target API 36, arm64-v8a only.
* Final frontend production build: **2.44 s**, TypeScript passed; worker output
  97.86 kB, main JS 634.73 kB, CSS 16.43 kB. Rust ARM64 release: **46.14 s**;
  Gradle release packaging/native compilation: **40 s**.
* Brief existing-emulator launch: `am start -W` returned Status ok, delivering
  the intent to its already-running Activity (9 ms wait, not a cold-start
  measurement). Its previously installed x86-64 wrapper was not replaced and
  does not validate this ARM64 frontend/native update. Current frontend smoke
  evidence is the generated-book browser review above. No physical update was
  performed because the phone was not connected.
* `git diff --check` passed; APK/captures remain ignored and testLibrary/ remains
  Git-ignored. Source-file safety was maintained throughout.

Approximate wall-time accounting: **32 minutes development/audit/review/docs and
24 minutes validation/builds/visual checks/waiting (~43% validation)**. Overlapping
agent work and documentation/build work are counted once, not added as separate
elapsed intervals. The unexpected file-chooser delay is included. The broad
16-test regression ran once; only the affected 4-test reader group was repeated
after the fullscreen request. Packaging was repeated for that relevant change,
and a failed TypeScript assertion required repair. No development was padded,
no second ABI build or broad prior acceptance matrix was repeated, and no budget
exception was needed.

## Phase 6 reader revision — 2026-10-04

The user rejected page navigation hidden in the control sheet and requested
horizontal phone reading. This revision supersedes the immersive handle-only
navigation and preservation of vertical reflowable typography described above.

* A 52 CSS-pixel bottom bar keeps Previous, Menu and Next visible with minimum
  48-pixel touch targets. It occupies its own space below the EPUB viewport;
  no text-edge tap regions intercept word lookup. Menu tap/upward swipe remains.
  Page buttons use existing serialized page-turn/boundary recovery. Pagination
  is retained; seamless scrolling and a writing-direction selector are deferred.
* Reflowable chapters use horizontal-tb and LTR text/pagination, established
  before serialization and after rendition startup. Spine order is unchanged.
  Publication alignment, indentation, character spacing and vertical modes are
  overridden for readable horizontal prose. Ruby markup and text nodes remain
  intact, with annotations above their bases. Fixed-layout pages are untouched.
  Linked CSS no longer needs loading/parsing solely to infer vertical modes.
* No desktop, dictionary, sync, storage schema or source-library changes were
  made by this revision. Prior uncommitted work was preserved.

Targeted regression: 14 tests passed in 5 files, Vitest 1.19 seconds. Includes
word-tap definitions/history, native position restore/save and lifecycle dedup,
menu swipe/exit, direct page turns without opening the menu, horizontal/ruby
presentation, fixed-layout preservation, passages and lookup history. First
restricted run could not load esbuild config; elevated rerun revealed two new
assertion issues (hidden-dialog accessible name and jsdom writing-mode priority),
corrected before the passing run. No broad desktop/native suites repeated.
TypeScript and production Vite build passed during ARM64 packaging (2.51 seconds).
Component smoke confirms both page buttons call the rendition with menu closed;
it is not a visual WebView or physical-phone typography acceptance test.

Install the new signed 0.6.1 / versionCode 6001 ARM64 update in place and check
horizontal prose in the problematic book, ruby, forward/backward chapter turns,
word taps, and retained position after restart/rotation. The older captures and
APK hash above describe 0.6.0, not this revision. Physical acceptance stays open.
Source EPUBs and source directories were not accessed or altered.

Revision artifact: same APK path as above, **88,876,979 bytes**, SHA-256
`f476cf7f9724871f556e9abd7f22378228af472b071abaa3c17d05989fd8ba97`.
ARM64 Rust release compiled in 46.98 seconds; Gradle packaging passed in 46
seconds. apksigner verification passed with the existing certificate SHA-256
`606342f7138cbc6eaee5b672b9d9961cc9ca70d2e3f4eacb53cbd4a47f543ca8`;
aapt confirms com.tmw.companion 0.6.1 / 6001. Initial signature invocation lacked
JAVA_HOME; verification passed after using the existing build JDK. No signing
key changes. git diff --check passed. Approximate revision time: 7 minutes
implementation/audit/documentation, 3 minutes validation/packaging (30%).
No device install or rendered real-book smoke was performed in this revision;
physical reader layout/position acceptance remains unverified.

## Phase 6 edge-tap revision — 2026-10-04

User requested edge taps while retaining the menu. Short stationary taps in the
blank outer 32 CSS pixels of the visible reader pane turn pages: right is Next,
left is Previous. Actual text glyphs take priority and still open lookup, even
within the edge band. Links, form controls and ruby annotations remain excluded.
The bottom bar/menu and horizontal presentation from 0.6.1 are retained.

Coordinates are translated from the chapter iframe into the visible pane before
checking the edge band; epub.js may translate an iframe containing many columns,
so its full document width cannot be used as the visible page width. Both tap
start and end must lie in the same edge band. Existing movement, scroll,
long-press and pointer-cancellation guards apply before either action. Existing
serialized page turning, chapter-boundary recovery and progress saving are reused.
No overlays intercept words; no EPUB contents or source directories are changed.

Targeted regression: **12 tests in 3 files passed**, Vitest 1.03 seconds. Covers
translated iframe edge turns, blank-center exclusion, moved-pointer exclusion,
ordinary word lookup/history, direct bottom controls, menu swipe/exit, progress
restore/save and lifecycle dedup, horizontal/ruby presentation and font bounds.
The new edge test initially included call history from an earlier lookup test;
its mock history was isolated and the targeted group rerun successfully.
No desktop/native broad suites or second ABI packaging were run.

Update version: **0.6.2 / 6002**, ARM64, same app identifier and signing key.
Real-phone edge reachability and chapter-boundary behavior remain pending;
component event smoke is not physical WebView acceptance. Install in place and
check right/left margin taps, words near the margins, menu, and saved position.
Source library/testLibrary were not accessed or modified. No database migration,
credentials, app data or sync protocol changes were made.

Edge-tap artifact: same APK path, **88,877,075 bytes**, SHA-256
`d81efc64d46e41c450101d96aa26c1ef36a73bf903c4f116cdbb673f0b7a30d4`.
TypeScript/production frontend build passed (Vite 2.55 seconds), Rust ARM64
release passed (42.86 seconds), Gradle packaging passed (45 seconds). APK
signature verified with the existing certificate recorded above; aapt confirms
0.6.2 / 6002. No device install was performed. Approximate time accounting:
4 minutes implementation/audit/docs, 2 minutes validation/package/waiting
(~33% validation); overlapping work counted once. git diff --check passed.
