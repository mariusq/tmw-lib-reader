# Android Phase 7 — personal-use updates and recovery

Implemented 2026-10-04. This checkpoint preserves the existing personal-use
signing identity and adds offline phone-data export. No persistent database
migration, source-library access, desktop implementation change, credential
reset, uninstall, data clear or signing-key replacement was performed.
Pre-existing uncommitted work through Phase 6 was preserved.

## Updating and protecting the signing key

Continue using `apps/android/Android.ps1 -Action Build -TestSigning -Target aarch64`.
The existing development keystore is now the established personal-use update key;
switching to a new production key would prevent updates to the installed app.
The build checks that `%USERPROFILE%\.android\debug.keystore` already exists and
that its `androiddebugkey` certificate has SHA-256 fingerprint
`606342f7138cbc6eaee5b672b9d9961cc9ca70d2e3f4eacb53cbd4a47f543ca8`.
It stops before Gradle if the key is missing or mismatched. Do not run Android
initialization or generate a new key to resolve that error. Direct Gradle builds
do not have the PowerShell preflight: use the supported launcher for updates.

Secure backup procedure (the key is private; never commit or share it):

1. Copy the existing keystore, without moving it, to a user-selected encrypted
   removable drive or encrypted offline vault outside this repository. Keep a
   second encrypted offline copy separately. A plain copy on C: alone is not a
   recovery backup. The development password `android` is not a security boundary;
   protect the storage containing the key.
2. Compare `Get-FileHash -Algorithm SHA256 -LiteralPath <original>` with the same
   command for the backup. Matching file hashes verify an exact copy. Do not put
   the keystore or passwords into logs, chats or version control.
3. Store the alias `androiddebugkey`, development store/key password `android`,
   application ID `com.tmw.companion`, and certificate fingerprint above in the
   secure vault alongside the key. Keep the matching SDK/JDK/build instructions.
4. On a replacement PC, restore the exact original file to the documented location
   before building. The launcher checks its certificate. Never replace a working
   key with a newly generated one. Losing the key prevents in-place updates;
   exporting phone data before any reinstall is then essential.

This task verified the existing key but did not create an encrypted backup on an
unspecified destination. The user must complete the secure copy procedure.

Install the signed APK using Android's package installer over the existing app,
or `adb -s <physical-phone-serial> install -r <APK>`. Do not uninstall, clear data,
use downgrade flags or wipe the device. Version 0.7.0 / code 7000 increases the
previous 0.6.2 / 6002. Export before installing if there are unsynced changes.

## Offline phone-data export

Open **Settings → Backup and recovery → Export phone data** and choose a trusted
local folder in Android's system Create Document picker. No network or paired PC
is required. Copy the resulting ZIP to a secure location off the phone; verify
that an archive reader opens it and shows `manifest.json` with `complete: true`,
`format: tmw-phone-recovery`, `version: 1`. The ZIP is unencrypted and includes
private notes, sentence excerpts and reading history. The picker may expose
third-party providers: choose a local destination for personal offline backup.

The archive contains UTF-8 JSON arrays under `tables/`, a manifest and
`reader-settings.json`. It exports a consistent SQLite snapshot through cursors,
without copying a live database or its WAL and without materializing the catalog
in WebView memory. Work runs on the native storage worker. The read snapshot
temporarily serializes database writers; very large exports can delay saves or
sync commits until it finishes, while the WebView remains independent.

Included: catalog metadata and stable identities, download descriptors, progress,
bookmarks/passages/notes, local-proof lookup history, synced history, tombstones,
pending operations in delivery order, provisional acknowledgments, rejected
operations, sync cursors/epochs/counters, history preferences, cache settings,
reader CFIs, font setting and last-reading descriptor. The acknowledged native
snapshot is authoritative; it cannot include a reader IPC that has not committed.
WebView reader settings are collected just before opening the picker and are
separate from the database snapshot. Export from Settings after leaving Reader.

Excluded: EPUB bytes (including manual IndexedDB proof copies), cover images,
dictionary data, credentials and Android Keystore secrets, transient catalog
staging/transfer files. Download filenames are descriptors, not portable copies.
Keep original manually imported books separately; PC books can be downloaded
again when the PC is available. Cover clearing/removing downloads does not remove
the durable user tables being exported. No app-managed second cover cache exists.

There is **no automatic restore/import UI** in this checkpoint. This is a usable
human-readable recovery export, not a promise of one-click restoration. To
recover a note/history record, open its table array and parse the `json` or
`operation` string within its row; `user_queue.operation` holds pending fields,
`user_rejected.json` preserves rejected fields and `user_provisional.json` holds
acknowledged overlays. Pair records with their namespace/book/version; do not
apply a CFI to a changed EPUB. Preserve the whole ZIP for future assisted restore.
Do not replay old queue rows directly into the sync API: operation IDs, sequence
counters, cursors and clear/delete tombstones must be reconciled together.

The completion manifest is written last and ZIP finalization must succeed before
the app reports success. Picker cancellation retains all local data. A caught
write failure attempts to remove only the newly created output document and
reports failure. OS process death/provider failure may leave a partial ZIP:
discard it and export again; local SQLite data is unchanged. There is no temporary
export archive or extra EPUB copy in the app's cover cache or source directories.

Uninstalling or clearing app storage deletes downloaded books, local metadata,
phone-only history and unsynced changes, along with the pairing credential.
Previously synced PC records remain on the PC. Android automatic backup remains
disabled. A ZIP stored outside app storage survives data clear, but may be lost
with the phone; maintain the off-phone copy. Any future destructive migration or
cleanup must explain its impact and point to this export before proceeding.

## Protocol compatibility

Pairing/status (v1), catalog import (v2) and user sync (v3) validate their protocol
version and report an explicit incompatibility message with update/export advice.
Missing sync endpoints (404) and unsupported protocol responses (426) are also
clear errors. Version checks occur before applying catalog pages or removing
acknowledged queue operations. Existing records, copies, credentials and queues
remain available; ordinary retry/backoff is retained. Namespace mismatch has a
separate local-data-retained message. No automatic wipe/re-pair is performed.

## Evidence and limitations

The user confirmed during this task that physical-phone in-place updates in the
previous phases successfully retained downloaded books, reading progress and
offline queued changes. This is user-reported physical acceptance, reused for
the stable signing/update behavior; it is not a claim that 0.7.0 or its new export
picker has been exercised on a physical phone. No physical phone was attached;
the existing emulator was the only adb device. Prior reader/dictionary/pairing,
offline and Windows evidence is reused because those implementations were not
changed here.

Targeted frontend regression: **11 tests in 4 files passed**, Vitest 1.11 seconds,
covering recovery UI/reader-state allowlist plus reader/history/passages behavior.
The initial restricted-shell run failed before test execution due to esbuild
parent-directory permissions; the approved rerun passed.

Focused native instrumentation: **2 tests passed**, 0.19 seconds, on the existing
Android 16/API 36 emulator. Export round-trip verifies Japanese text, every
durable table, reader CFI, complete manifest, credential exclusion and unchanged
source rows. Incompatible-v99 sync leaves queued operations and phone history
intact. These fixtures exercise native export and sync gating, not a physical
DocumentProvider write. The x86-64 native test wrapper reused the existing Rust
library; no second Rust ABI rebuild was performed. Wrapper/test APKs installed
with `-r`, preserving app data. Brief Activity launch returned Status ok
(1058 ms cold Activity time; not a dictionary cold-start benchmark).

ARM64 production frontend/TypeScript build passed (Vite 2.68 seconds), Rust
release compiled in 53 seconds, Gradle release packaging/native compilation
passed in 48 seconds. `apksigner verify --print-certs` passed with the unchanged
certificate above. `aapt dump badging` confirms `com.tmw.companion`, 0.7.0 / 7000.
The package contains the final protocol-endpoint error handling; the focused
instrumentation wrapper checked the version-response guard and export helper.
Existing large-chunk and Gradle/Java deprecation warnings remain.

Signed APK:
`apps/android/src-tauri/gen/android/app/build/outputs/apk/arm64/release/app-arm64-release.apk`

SHA-256: `5ed8dc50346b7c77568768ef459b003238314e598588c731de6c5b40232dc27c`.
The APK and all generated assets remain ignored. `git diff --check` passed.
Source EPUBs, `F:\tmw collection` and `testLibrary/` were not accessed or altered.

Approximate time accounting: 10 minutes audit/implementation/documentation and
3 minutes non-overlapping validation/build/test waiting (about 23% validation).
Parallel build/test intervals and documentation written during compilation count
once. Only the targeted frontend regression, focused native checks, one ARM64
release build/signature check and brief emulator launch were run. No broad
Windows suite, second Rust ABI build, device wipe or redundant prior acceptance
matrix was run. No testing-budget exception was needed.

Remaining practical checks: save/open a recovery ZIP through the physical phone's
DocumentProvider and complete the user-selected encrypted signing-key backup.
The native export format passed instrumentation; physical picker/provider behavior
and a fresh 0.7.0 physical install were not claimed as tested. Automatic restore,
process-death export fault injection and a large-catalog export latency measurement
remain unimplemented/unmeasured, respectively.
