# Global browser cover visibility

Both desktop and Android book browsers have a single Show covers checkbox.
Unchecking it blurs all browser cover images with a 12px CSS filter. Titles,
controls, completion badges and missing-cover placeholders remain readable.
The preference defaults to checked and persists locally on each device in
WebView localStorage (`tmw-show-covers`); it is not a per-book or synced setting.
Desktop applies the preference to both grid and list layouts. Toggling does not
refetch the catalog or regenerate cover files. Source EPUBs were not accessed.

Validation: both TypeScript/Vite production frontend builds passed, as did all
three existing LibraryShell regression tests and git diff --check. Initial
restricted-shell Vite attempts failed on directory access; authorized retries
passed. Approximate time: four minutes implementation/readback, under one minute
validation, with overlapping checks counted once. No native Windows package,
Android APK, emulator or physical-phone smoke test was performed for this CSS
and frontend-state change. Physical rendering and persistence remain unverified.
