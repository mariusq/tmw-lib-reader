# Android Phase 5 — progress and user-data sync

Implemented on 2026-10-04. Phase 6 UI/lifecycle redesign and Phase 7 export/release
hardening remain separate work. Existing dirty Phase 4 changes were preserved.

## Behavior

Catalog downloads carry catalog namespace, public book ID and verified content
version into the reader. Reader relocation saves the existing content-keyed
WebView position and immediately submits a native SQLite operation. Native saves
commit a durable operation and device sequence together before acknowledging the
UI. The queue is the local overlay; it survives process termination independently
of credentials, downloaded copies and covers. The manually imported proof book
and its old positions are preserved; it has no inferred cross-device identity and
does not participate in sync.

The reader adds page bookmarks and lookup excerpts with notes. Saved passages
support independent excerpt/note edits and deletion. Notes can also be viewed
and edited through the catalog without a local EPUB. Lists are paged by 50;
unknown or different content versions retain their text with anchor navigation
disabled. Native progress restoration requires the exact downloaded hash.

Native sync starts automatically after storage initialization when a catalog is
selected, checks on a 30-second schedule, and retries failures with exponential
backoff up to five minutes. A run sends at most 16 operations per request and
pulls at most 100 pages; remaining pages continue on a later run. The visible
status reports pending work, failures and retained rejected operations, and offers
a manual retry. Network work runs outside the UI/local-save executor. Android
OS scheduling while the process is suspended or killed is not implemented;
reopening the app resumes durable work. Phase 6 owns lifecycle polish.

The desktop adds the authenticated v3 user-sync endpoint while preserving v1/v2
pairing, catalog and download APIs. Progress uses serialized server commit order,
including backwards movement. Device operation IDs make retries idempotent and
device counters preserve queued delivery order without relying on phone time.
Passage edits patch only specified sentence/note fields; deletion creates a
permanent tombstone. A new save after deletion requires a new identity. Desktop
edits are journaled transactionally and flow back to the phone. See
[phase5-protocol.md](phase5-protocol.md) for exact bounds and ordering rules.

Acknowledged operations remain as durable provisional overlays until the pull
cursor reaches the server's `highWater`. This prevents a committed local edit
from disappearing while older journal pages are being pulled. Interrupted page
application cannot advance the cursor without its changes. A restore epoch resets
derived mobile records; true pending operations remain queued. Old provisional
acknowledgments are archived visibly for recovery before replaying restored PC
state, so an old watermark cannot permanently override the restored catalog.

Source replacement/unavailability rejects new mismatched anchors. The phone
retains their local version-specific state and recovery text rather than applying
them to a different EPUB. Existing passage text edits/deletions do not require
the source to be online. A deleted PC book rejects incoming changes without
erasing downloaded copies or durable phone records. No metadata/tag/collection
editing is added.

## Storage and safety

Desktop schema 17 is additive and preserves existing metadata, progress and
passages. Backup/import compatibility tests include migration from older schemas
and restoring current backups. No destructive migration, live-database exchange
or source cleanup was performed. Use the desktop Backup action before a future
destructive operation; an example destination is
`%USERPROFILE%\Documents\TMW backups\catalog-before-sync.sqlite3`, outside all
source roots.

Mobile user tables are added idempotently to the existing app-private
`files/tmw-mobile/catalog.sqlite3`. Copy removal and thumbnail clearing do not
touch them. Recovery copies, the pending queue and device sequence remain durable.
The private app-data backup boundary remains `/data/user/0/com.tmw.companion/`;
user-facing export is Phase 7. Credentials remain Keystore-backed and native;
they never enter React or EPUB documents.

The actual `F:\tmw collection` and `testLibrary/` were not accessed or altered in
this task. All source-version reads in the implementation use approved read-only
handles. Tests use isolated generated fixtures or synthetic state. No EPUB was
uploaded, moved, renamed, modified or deleted. The existing Tailscale Serve
configuration, pairing keys and source drive were not changed.

## Validation

* Desktop Rust regression: **46 passed, 7 ignored**. The initial run found two
  generated downgrade fixtures which retained new schema-17 objects; fixtures
  now remove those objects before simulating old schemas. Subsequent targeted
  sync tests and the authenticated HTTP regression passed. Coverage includes
  transactional rollback, duplicate delivery, server ordering/backwards progress,
  field merges/null clears, terminal tombstones, replacement/unavailability,
  pagination/restart, authorization and epoch rejection. A subsequent focused HTTP
  regression (**2.65 seconds**) verifies note edits and deletion without reading
  a generated source larger than the transfer limit. The `highWater`
  regression accepts an operation behind 65 journal records, then reaches its
  acknowledgment watermark after restart.
* Android frontend regression: **7 tests passed** in the final Android group;
  subsequent pagination coverage adds one test, with the affected passage group
  **3 passed**. Together these are eight distinct tests. TypeScript and ESLint
  passed; the Android Vite production build passed with its existing chunk-size
  warning. Tests exercise version-safe restore, durable relocation submission,
  field-only edits, stable-ID deletion, legacy notes without a download,
  pagination, stale catalog responses and touch disambiguation.
* Native Android instrumentation uses the existing Android 16/API 36 x86-64
  emulator and isolated databases. Coverage includes offline save/restart,
  response loss after server commit, ordered idempotent retry, old-version
  isolation, legacy notes and pagination, retained rejections, later successful
  edits, acknowledged-but-unpulled changes across restart, and restore epochs.
  Final result: **5 passed in 0.659 seconds**. A concrete JSON boolean mismatch found during
  the final run was repaired using SQLite `json('false')`; only affected native
  wrappers/tests were rebuilt.
* The final standalone Windows release build with `tauri/custom-protocol`
  passed in **29.92 seconds** after the final source-independent note/delete fix. The running
  desktop was not restarted against the user's live catalog. Earlier build
  evidence was reused; no Windows installer was generated.
* ARM64 release-profile packaging uses the existing development signing key,
  package `com.tmw.companion`, version **0.5.0**, versionCode **5000**.
  It includes the new frontend and native storage. The final artifact is
  **88,839,711 bytes**; SHA-256
  `942d98f15c0955231880d04e2feaca7efc01cc676eaf07912d98b3936cf4cee7`.
  APK v2 signature verification and 16 KB ZIP alignment passed. APKs, dictionaries, keys, fixture
  databases and generated JNI outputs remain ignored.

Commands from the repository root:

```powershell
cargo test --offline --manifest-path src-tauri/Cargo.toml --lib
cargo test --offline --manifest-path src-tauri/Cargo.toml --lib user_sync
cargo test --offline --manifest-path src-tauri/Cargo.toml --lib companion::tests::private_api
cargo build --offline --manifest-path src-tauri/Cargo.toml --release --features tauri/custom-protocol
& 'C:\Program Files\nodejs\npm.cmd' exec vitest -- run apps/android/src
& 'C:\Program Files\nodejs\npm.cmd' exec vitest -- run apps/android/src/SavedPassages.test.tsx
& 'C:\Program Files\nodejs\npm.cmd' exec tsc -- --noEmit -p apps/android/tsconfig.json
& 'C:\Program Files\nodejs\npm.cmd' exec eslint -- apps/android/src
& .\apps\android\Android.ps1 -Action Build -TestSigning -Target aarch64
# SDK/Java/Gradle paths are the existing documented installation.
$native='apps/android/src-tauri/gen/android'
& "$native/gradlew.bat" -p $native assembleArm64Release assembleX86_64Debug assembleX86_64DebugAndroidTest -x rustBuildArm64Release -x rustBuildX86_64Debug -PtmwTestSigning=true --offline --no-daemon --no-configuration-cache
adb -s emulator-5554 install -r <debug-wrapper.apk>
adb -s emulator-5554 install -r <debug-test.apk>
adb -s emulator-5554 shell am instrument -w -e class com.tmw.companion.UserSyncStorageTest com.tmw.companion.test/androidx.test.runner.AndroidJUnitRunner
apksigner verify --verbose <arm64-release.apk>
zipalign -c -P 16 4 <arm64-release.apk>
git diff --check
```

Restricted esbuild and ADB/Gradle cache access required approved shells; this was
not an npm/toolchain installation defect. Late durability repairs reused the
completed ARM64 frontend/Rust output and rebuilt only Kotlin/wrapper packaging.
The x86-64 instrumentation wrapper reuses its existing Phase 4 Rust/frontend
assets; it tests the new native storage, not the complete new frontend on Android.
No second ABI Rust rebuild was performed. The existing emulator was updated in
place without uninstalling or clearing data.

The brief emulator wrapper launch passed (`am start -W`, cold activity start
**1,126 ms**). This is activity launch timing, not the new reader/frontend readiness
or private-connection performance. No physical device was attached. Existing
WebView reader data, dictionary, credentials and signing identity were preserved.

Approximate wall-time accounting: **27 minutes implementation/review/documentation
and 7 minutes validation/builds/packaging/smoke (~21% validation)**. Failed attempts
and necessary repair reruns are included. Overlapping validation is counted once
and excluded from development. Prior Phase 1–4 acceptance evidence was reused;
no testing-budget exception or padded development time was needed.

## Remaining physical acceptance

Install the ARM64 APK in place and use the updated standalone Windows executable.
Explicitly enable the existing private service; keep the PC awake. Re-pair with a
fresh code if the phone grant remains revoked, then refresh the catalog. Open a
downloaded book, change position and add a note while offline, restart, reconnect
and confirm convergence with the desktop. Also test a desktop edit/deletion and
phone retry after the private connection drops. Neither physical-phone sync nor
real tailnet latency/battery behavior is claimed by fixture tests. Existing
dictionary and source safety evidence is reused. UI redesign, lifecycle and
background OS scheduling, metadata edits, public hosting and cloud sync are not
part of this phase.

## User-confirmed physical-phone acceptance — 2026-10-04

Before Phase 6, the user confirmed that everything passed on the physical phone
after Phase 5.5, including the prior Phase 5 behavior. This is user-reported
acceptance, separate from the automated/emulator evidence above. Earlier pending
physical acceptance lists are superseded by this report; no phone timings or
device details were supplied. Phase 6 changes require fresh physical acceptance.
